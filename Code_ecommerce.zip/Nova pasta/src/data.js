export default {
    products: [
        {
            _id: 1,
            name: 'Cozido 1',
            category: 'meals',
            image: '/images/d1.jpg',
            price: 50,
            description: 'asdasdsadasdas',
            rating: 4.0,
            numReviews: 10            
        },

        {
            _id: 2,
            name: 'Cozido 2',
            category: 'meals',
            image: '/images/d1.jpg',
            price: 51,
            description: '1asdasdsadasdas',
            rating: 4.2,
            numReviews: 11         
        },

        {
            _id: 3,
            name: 'Cozido 3',
            category: 'desserts',
            image: '/images/d1.jpg',
            price: 53,
            description: '3asdasdsadasdas',
            rating: 4.235,
            numReviews: 102            
        },
    ]      
}